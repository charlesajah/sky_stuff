#############################################################################################################################################
###The files deploy_db_objects.sh, df_h.sh , setup_cron.sh and setup_df_h.sh are all part of the deploy_tactical_tspace_monitoring.yaml script.
###Thesse files will be copied to the remote servers and executed remotely.
#############################################################################################################################################
***setup_cron.sh***
modifies the crontab and adds a cron job that runs once every minute.
This job processes the output of df -h(df_h.sh) into a csv file called df_output.csv.
This csv file is the basis of the external table called FILESYSTEM that exists in Oracle database.
The idea is that a query of the external table should give you near real-time view of the spaces utilisation in the filesystem.

The tablespace python job uses this external table to decide which filesystem(s) is/are eligible to receive a new datafile.

***setup_df_h.sh***
it simply sets up the directory where the csv file and the df_h.sh script will be located

***deploy_db_objects.sh***
This script is used to deploy the database objects needed for the task to run like a database directory and an external table.
