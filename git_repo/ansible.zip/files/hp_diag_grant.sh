#!/bin/bash
####################################################################
# Name : onxsmpgpdbn05:/apps/ora/home/ansible/files/hp_diag_grant.sh
# Purpose : Grant AWR privileges to user hp_diag so can run these jenkins jobs:
#    https://ppejenkins.bskyb.com/view/NFT%20DBA/view/NFT%20DBA%20-%20Analysis%20Jobs/job/NFT%20DBA%20-%20AWR%20Report%20Generation/
#    https://ppejenkins.bskyb.com/view/NFT%20DBA/view/NFT%20DBA%20-%20Analysis%20Jobs/job/NFT%20DBA%20-%20AWR%20Auto%20Generation%20(N02)/
# Change History :
#    07-Oct-2022 Andrew Fraser initial version
####################################################################
export ORACLE_SID=$1
export NFT_ENV=$2
if [ ! -z $3 ]
then
  l_pdbCommand="alter session set container = $3 ;"
fi
echo Checking before ORAENV_ASK
export ORAENV_ASK=NO
. oraenv > /dev/null
unset ORAENV_ASK
echo Checking after unset ORAENV_ASK command
sqlplus -s /nolog << END_SQL
select sysdate from dual;
conn / as sysdba
select sysdate from dual;
$l_pdbCommand
set serveroutput on feedback off pages 9999 lines 130
DECLARE
   l_count NUMBER ;
   l_name varchar2(100);
   l_sqltxt  varchar2(150);
BEGIN
   select name into l_name from v\$database;
   dbms_output.put_line ('Database name is '||l_name);
   IF sys_context ( 'userenv' , 'database_role' ) = 'PRIMARY'
   THEN
      SELECT COUNT(*) INTO l_count
        FROM dba_users
       WHERE username = 'HP_DIAG'
      ;
      IF l_count = 1
      THEN
		l_sqltxt := 'create or replace directory KEEP_INFO_REFRESH as ''/share/dbnth/VOLUME_REFRESH/KEEP_INFO_NFT/'||'${NFT_ENV}'||'/REFRESH''';
	      	dbms_output.put_line (l_sqltxt);
      		execute immediate l_sqltxt;
 		l_sqltxt := 'create or replace directory KEEP_INFO_NFT as ''/share/dbnth/VOLUME_REFRESH/KEEP_INFO_NFT/'||'${NFT_ENV}'||'''';
		dbms_output.put_line (l_sqltxt);
 		execute immediate l_sqltxt;
		DBMS_OUTPUT.PUT_LINE('Grants on directories KEEP_INFO_REFRESH and KEEP_INFO_NFT successful on database '||l_name);

                dbms_output.put_line ( 'Info: action: granting multiple privileges to user hp_diag on '||l_name ) ;
                execute immediate 'GRANT EXECUTE ON sys.dbms_workload_repository TO hp_diag' ;
                EXECUTE IMMEDIATE 'GRANT SELECT ON dba_sql_profiles TO HP_DIAG';
                EXECUTE IMMEDIATE 'GRANT SELECT ON dba_sql_plan_baselines TO HP_DIAG';
                EXECUTE IMMEDIATE 'ALTER USER HP_DIAG QUOTA UNLIMITED ON USERS_AUTO_01';
                EXECUTE IMMEDIATE 'GRANT ADMINISTER SQL MANAGEMENT OBJECT TO HP_DIAG';
                EXECUTE IMMEDIATE 'GRANT EXECUTE ON SYS.DBMS_CRYPTO TO HP_DIAG';
                EXECUTE IMMEDIATE 'GRANT EXECUTE ON SYS.DBMS_WORKLOAD_REPOSITORY TO HP_DIAG';
                EXECUTE IMMEDIATE 'GRANT ADMINISTER SQL TUNING SET TO HP_DIAG';
                EXECUTE IMMEDIATE 'GRANT CREATE ANY TABLE TO HP_DIAG';
                EXECUTE IMMEDIATE 'GRANT CREATE PROCEDURE TO HP_DIAG';
                EXECUTE IMMEDIATE 'GRANT RESOURCE TO HP_DIAG';
                EXECUTE IMMEDIATE 'GRANT ALTER DATABASE TO HP_DIAG';
                EXECUTE IMMEDIATE 'GRANT READ , WRITE ON DIRECTORY KEEP_INFO_REFRESH to HP_DIAG';
		EXECUTE IMMEDIATE 'GRANT READ , WRITE ON DIRECTORY KEEP_INFO_NFT to HP_DIAG';
                EXECUTE IMMEDIATE 'grant create session, create table, exp_full_database, imp_full_database to hp_diag';
		DBMS_OUTPUT.PUT_LINE('All privileges granted successfully on '||l_name);
      ELSE
         dbms_output.put_line ( 'Error: user hp_diag not found on '||l_name ) ;
      END IF ;

      SELECT COUNT(*) INTO l_count
        FROM dba_users
       WHERE username = 'DATAPROV'
      ;
      IF l_count = 1
      THEN
         SELECT COUNT(*) INTO l_count
           FROM dba_tab_privs
          WHERE grantee = 'DATAPROV'
            AND owner = 'SYS'
            AND table_name = 'DBMS_LOCK'
            AND privilege = 'EXECUTE'
         ;
         IF l_count = 0
         THEN
            dbms_output.put_line ( 'Info: action: granting DBMS_LOCK privilege to user dataprov on '||l_name ) ;
            execute immediate 'GRANT EXECUTE ON sys.DBMS_LOCK TO dataprov' ;
         ELSE
            dbms_output.put_line ( 'Info: no action taken: user dataprov already had required DBMS_LOCK privilege on '||l_name ) ;
         END IF ;

         SELECT COUNT(*) INTO l_count
           FROM dba_tab_privs
          WHERE grantee = 'DATAPROV'
            AND owner = 'SYS'
            AND table_name = 'DBMS_CRYPTO'
            AND privilege = 'EXECUTE'
         ;
         IF l_count = 0
         THEN
            dbms_output.put_line ( 'Info: action: granting DBMS_CRYPTO privilege to user dataprov on '||l_name ) ;
            execute immediate 'GRANT EXECUTE ON sys.DBMS_CRYPTO TO dataprov' ;
         ELSE
            dbms_output.put_line ( 'Info: no action taken: user dataprov already had required DBMS_CRYPTO privilege on '||l_name ) ;
         END IF ;

        dbms_output.put_line ( 'Info: action: granting v_\$session privilege to user dataprov on '||l_name ) ;
        execute immediate 'GRANT select ON sys.v_\$session TO dataprov' ; 
      ELSE
         dbms_output.put_line ( 'Error: user dataprov not found on '||l_name ) ;
      END IF ;
   ELSE
      dbms_output.put_line ( 'Info: no action taken: database is not primary on '||l_name ) ;
   END IF ;
END ;
/
exit ;
END_SQL
# (end of file).
