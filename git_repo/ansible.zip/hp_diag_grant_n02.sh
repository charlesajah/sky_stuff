#!/bin/bash
# https://confluence.bskyb.com/display/nonfuntst/Post+Environment+Refresh+hp_diag+grant+Ansible+Script
cd ~/ansible
ansible-playbook hp_diag_grant.yaml --limit n02
echo 'CSC021N start ****************************************************************************************************************'
echo 'CSC has an old version OS, incompatible with ansible, so being run old fashioned way by shell script...'
ssh ccapedbn02.bskyb.com -q -i ~/.ssh/ansible_key 'bash -s CSC021N' < ~/ansible/files/hp_diag_grant.sh
echo 'CSC021N end ******************************************************************************************************************'
