#!/bin/bash
# https://confluence.bskyb.com/display/nonfuntst/Post+Environment+Refresh+hp_diag+grant+Ansible+Script
cd ~/ansible
ansible-playbook create_KEEP_INFO_REFRESH.yaml --limit n01
echo 'CSC011N start ****************************************************************************************************************'
echo 'CSC has an old version OS, incompatible with ansible, so being run old fashioned way by shell script...'
ssh ccapedbn01.bskyb.com -q -i ~/.ssh/ansible_key 'bash -s CSC011N N01' < ~/ansible/files/create_KEEP_INFO_REFRESH.sh
echo 'CSC011N end ******************************************************************************************************************'
