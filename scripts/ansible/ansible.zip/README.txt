Documentation:
  https://confluence.bskyb.com/display/nonfuntst/Post+Environment+Refresh+hp_diag+grant+Ansible+Script

Usage
  $ ~/ansible/hp_diag_grant_n01.sh  #(for n01)
  $ ~/ansible/hp_diag_grant_n02.sh  #(for n02)

To add a new target host/database into the list:
  1) Append the line in "cat ~oracle/.ssh/ansible_key.pub" from this server,
       onto the end of file "~oracle/.ssh/authorized_keys" on each target database server.
  2) Add a line into file "~oracle/ansible/inventory.ini" of this server,
       one line per host/database combination.
       ORACLE_SID variable is required.
       pdb_name variable is optional, only needed for pluggable databases.
  3) Smoke test limited to just one specific target host/database with (on this server) e.g.:
       $ cd ~oracle/ansible
       $ ansible-playbook hp_diag_grant.yaml --limit oms021n_sce
     Substitute in the correct name in place of "oms021n_sce"
     The first time it is run, you will be prompted "Are you sure you want to continue connecting"
       a "yes" answer will be remembered so future runs work without prompting.

Can also make use of this for command prompt access to target servers as oracle, e.g.:
  $ ssh ccapedbn02.bskyb.com -i ~/.ssh/ansible_key
