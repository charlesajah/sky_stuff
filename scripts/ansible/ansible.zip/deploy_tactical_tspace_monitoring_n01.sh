#!/bin/bash
# https://confluence.bskyb.com/display/nonfuntst/Post+Environment+Refresh+hp_diag+grant+Ansible+Script
cd ~/ansible
ansible-playbook deploy_tactical_tspace_monitoring.yaml  --limit n01
echo 'CSC011N start ****************************************************************************************************************'
echo 'CSC has an old version OS, incompatible with ansible, so being run old fashioned way by shell script...'
ssh ccapedbn01.bskyb.com -q -i ~/.ssh/ansible_key 'bash -s CSC011N' < ~/ansible/files/deploy_tactical_tspace_monitoring.sh
echo 'CSC011N end ******************************************************************************************************************'

