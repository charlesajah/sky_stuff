#!/bin/bash
###############################################################################
# Name : onxsmpgpdbn05:/apps/ora/home/ansible/files/create_KEEP_INFO_NFT.sh
# Purpose : Create KEEP_INFO_NFT directory
# Change History :
#    30-Sep-2024 - RFA - Created
###############################################################################
export ORACLE_SID=$1
export NFT_ENV=$2
if [ ! -z $3 ]
then
  l_pdbCommand="alter session set container = $3 ;"
fi
export ORAENV_ASK=NO
. oraenv > /dev/null
unset ORAENV_ASK
sqlplus -s /nolog << END_SQL
conn / as sysdba
$l_pdbCommand
set serveroutput on feedback off pages 9999 lines 130
DECLARE
   name    varchar2(30);
   sqltxt  varchar2(100);
BEGIN
   select name into name from v\$database;
   DBMS_OUTPUT.PUT_LINE('.......................................................................................................');
   DBMS_OUTPUT.PUT_LINE('Starting with database '||name);
   IF sys_context ( 'userenv' , 'database_role' ) != 'PRIMARY'
   THEN
      raise_application_error(-20002,'Script is only allowed on Primary databases.');
   ELSE
      sqltxt := 'create or replace directory KEEP_INFO_NFT as ''/share/dbnth/VOLUME_REFRESH/KEEP_INFO_NFT/'||'${NFT_ENV}'||'''';
      dbms_output.put_line (sqltxt);
      execute immediate sqltxt;
   END IF;
   DBMS_OUTPUT.PUT_LINE('Execution completed successfully on database '||name);
END ;
/
exit ;
END_SQL
# (end of file).
