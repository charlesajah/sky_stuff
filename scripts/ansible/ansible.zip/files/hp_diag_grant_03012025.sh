#!/bin/bash
####################################################################
# Name : onxsmpgpdbn05:/apps/ora/home/ansible/files/hp_diag_grant.sh
# Purpose : Grant AWR privileges to user hp_diag so can run these jenkins jobs:
#    https://ppejenkins.bskyb.com/view/NFT%20DBA/view/NFT%20DBA%20-%20Analysis%20Jobs/job/NFT%20DBA%20-%20AWR%20Report%20Generation/
#    https://ppejenkins.bskyb.com/view/NFT%20DBA/view/NFT%20DBA%20-%20Analysis%20Jobs/job/NFT%20DBA%20-%20AWR%20Auto%20Generation%20(N02)/
# Change History :
#    07-Oct-2022 Andrew Fraser initial version
####################################################################
export ORACLE_SID=$1
if [ ! -z $2 ]
then
  l_pdbCommand="alter session set container = $2 ;"
fi
echo Checking before ORAENV_ASK
export ORAENV_ASK=NO
. oraenv > /dev/null
unset ORAENV_ASK
echo Checking after unset ORAENV_ASK command
sqlplus -s /nolog << END_SQL
select sysdate from dual;
conn / as sysdba
select sysdate from dual;
$l_pdbCommand
set serveroutput on feedback off pages 9999 lines 130
DECLARE
   l_count NUMBER ;
BEGIN
   dbms_output.put_line ('Database name is '||ORACLE_SID);
   IF sys_context ( 'userenv' , 'database_role' ) = 'PRIMARY'
   THEN
      SELECT COUNT(*) INTO l_count
        FROM dba_users
       WHERE username = 'HP_DIAG'
      ;
      IF l_count = 1
      THEN
         SELECT COUNT(*) INTO l_count
           FROM dba_tab_privs
          WHERE grantee = 'HP_DIAG'
            AND owner = 'SYS'
            AND table_name = 'DBMS_WORKLOAD_REPOSITORY'
            AND privilege = 'EXECUTE'
         ;
         IF l_count = 0
         THEN
            dbms_output.put_line ( 'Info: action: granting privilege to user hp_diag on $1 $2' ) ;
            execute immediate 'GRANT EXECUTE ON sys.dbms_workload_repository TO hp_diag' ;
         ELSE
            dbms_output.put_line ( 'Info: no action taken: user hp_diag already had required privilege on $1 $2' ) ;
         END IF ;
      ELSE
         dbms_output.put_line ( 'Error: user hp_diag not found on $1 $2' ) ;
      END IF ;

      SELECT COUNT(*) INTO l_count
        FROM dba_users
       WHERE username = 'DATAPROV'
      ;
      IF l_count = 1
      THEN
         SELECT COUNT(*) INTO l_count
           FROM dba_tab_privs
          WHERE grantee = 'DATAPROV'
            AND owner = 'SYS'
            AND table_name = 'DBMS_LOCK'
            AND privilege = 'EXECUTE'
         ;
         IF l_count = 0
         THEN
            dbms_output.put_line ( 'Info: action: granting DBMS_LOCK privilege to user dataprov on $1 $2' ) ;
            execute immediate 'GRANT EXECUTE ON sys.DBMS_LOCK TO dataprov' ;
         ELSE
            dbms_output.put_line ( 'Info: no action taken: user dataprov already had required DBMS_LOCK privilege on $1 $2' ) ;
         END IF ;

         SELECT COUNT(*) INTO l_count
           FROM dba_tab_privs
          WHERE grantee = 'DATAPROV'
            AND owner = 'SYS'
            AND table_name = 'DBMS_CRYPTO'
            AND privilege = 'EXECUTE'
         ;
         IF l_count = 0
         THEN
            dbms_output.put_line ( 'Info: action: granting DBMS_CRYPTO privilege to user dataprov on $1 $2' ) ;
            execute immediate 'GRANT EXECUTE ON sys.DBMS_CRYPTO TO dataprov' ;
         ELSE
            dbms_output.put_line ( 'Info: no action taken: user dataprov already had required DBMS_CRYPTO privilege on $1 $2' ) ;
         END IF ;

        dbms_output.put_line ( 'Info: action: granting v_\$session privilege to user dataprov on $1 $2' ) ;
        execute immediate 'GRANT select ON sys.v_\$session TO dataprov' ; 
      ELSE
         dbms_output.put_line ( 'Error: user dataprov not found on $1 $2' ) ;
      END IF ;
   ELSE
      dbms_output.put_line ( 'Info: no action taken: database is not primary on $1 $2' ) ;
   END IF ;
END ;
/
exit ;
END_SQL
# (end of file).
