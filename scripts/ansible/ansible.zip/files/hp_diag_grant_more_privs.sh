#!/bin/bash
###############################################################################
# Name : onxsmpgpdbn05:/apps/ora/home/ansible/files/hp_diag_grant_more_privs.sh
# Purpose : additional grants for HP_Diag
# Change History :
#    30-Jul-2024 Charles Ajah initial version
###############################################################################
export ORACLE_SID=$1
if [ ! -z $2 ]
then
  l_pdbCommand="alter session set container = $2 ;"
fi
export ORAENV_ASK=NO
. oraenv > /dev/null
unset ORAENV_ASK
sqlplus -s /nolog << END_SQL
conn / as sysdba
$l_pdbCommand
set serveroutput on feedback off pages 9999 lines 130
DECLARE
   name varchar2(100);
BEGIN
select name into name from v\$database;
DBMS_OUTPUT.PUT_LINE('.......................................................................................................');
DBMS_OUTPUT.PUT_LINE('Starting with database '||name);
   IF sys_context ( 'userenv' , 'database_role' ) != 'PRIMARY'
   THEN
	raise_application_error(-20002,'Script is only allowed on Primary databases.');
   ELSE

   	EXECUTE IMMEDIATE 'GRANT SELECT ON dba_sql_profiles TO HP_DIAG';
   	EXECUTE IMMEDIATE 'GRANT SELECT ON dba_sql_plan_baselines TO HP_DIAG';
   	EXECUTE IMMEDIATE 'ALTER USER HP_DIAG QUOTA UNLIMITED ON USERS_AUTO_01';
   	EXECUTE IMMEDIATE 'GRANT ADMINISTER SQL MANAGEMENT OBJECT TO HP_DIAG';
   	EXECUTE IMMEDIATE 'GRANT EXECUTE ON SYS.DBMS_CRYPTO TO HP_DIAG';
   	EXECUTE IMMEDIATE 'GRANT EXECUTE ON SYS.DBMS_WORKLOAD_REPOSITORY TO HP_DIAG';
   	EXECUTE IMMEDIATE 'GRANT ADMINISTER SQL TUNING SET TO HP_DIAG';
   	EXECUTE IMMEDIATE 'GRANT CREATE ANY TABLE TO HP_DIAG';
   	EXECUTE IMMEDIATE 'GRANT CREATE PROCEDURE TO HP_DIAG';
   	EXECUTE IMMEDIATE 'GRANT RESOURCE TO HP_DIAG';
   	EXECUTE IMMEDIATE 'GRANT ALTER DATABASE TO HP_DIAG';
	EXECUTE IMMEDIATE 'GRANT READ ON DIRECTORY KEEP_INFO_REFRESH to HP_DIAG';
        EXECUTE IMMEDIATE 'GRANT WRITE ON DIRECTORY KEEP_INFO_REFRESH to HP_DIAG';
   	EXECUTE IMMEDIATE 'grant create session, create table, create procedure, exp_full_database, imp_full_database to hp_diag';   
  END IF;
 DBMS_OUTPUT.PUT_LINE('Execution completed successfully on database '||name);
END ;
/
exit ;
END_SQL
# (end of file).
