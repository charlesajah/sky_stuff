break on manager_id skip 1
 
select manager_id, first_name, last_name
from hr.employees
order by 1 desc;
