#!/bin/bash -x

###############################################
#
# Bash script to rsync WAL files to wal archive
# on both servers (master and standby)
# using rsync via ssh password-less connection
#
# If no standby, ip2 set to space
###############################################

PGDATA=/data01/data

# define archive directory for WAL files
wal_archive_dir=/data02/pg_wal_archive

# define master and standby IP's
ip1="ud-0010627.bskyb.com"
ip2="ud-0010628.bskyb.com"

# define log file
log_file=${PGDATA}/log/archive_wal.log

# assign the argument values
wal_file_full_path=$PGDATA/$1
wal_file=$2

ip1_copy_failed=0
ip2_copy_failed=0

echo $(/bin/date)": Start archiving WAL files to local & remote disk into ${wal_archive_dir}" >> ${log_file}

# Copy archives to IP1
/usr/bin/rsync -a ${wal_file_full_path} ${ip1}:${wal_archive_dir}/${wal_file} >> ${log_file} 2>&1

if [ $? -eq 0 ]; then
    echo $(/bin/date)": Archiving of WAL file ${wal_file_full_path} on ip1 succeeded!" >> ${log_file}
else
    ip1_copy_failed=1
    echo $(/bin/date)": Archiving of WAL file ${wal_file_full_path} on ip1 failed!" >> ${log_file}
fi


# Copy archives to ip2 if not set to 0

if [[ ${ip2} == " " ]]; then
    echo "ip2 = ' '"
else
    /usr/bin/rsync -a ${wal_file_full_path} ${ip2}:${wal_archive_dir}/${wal_file} >> ${log_file} 2>&1

    if [ $? -eq 0 ]; then
        echo $(/bin/date)": Archiving of WAL file ${wal_file_full_path} on ip2 succeeded!" >> ${log_file}
    else
        ip2_copy_failed=1
        echo $(/bin/date)": Archiving of WAL file ${wal_file_full_path} on ip2 failed!" >> ${log_file}
    fi
fi

echo "################################" >> ${log_file}

exit 0


